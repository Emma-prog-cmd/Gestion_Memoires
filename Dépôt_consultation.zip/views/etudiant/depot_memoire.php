<?php
/**
 * VUE — views/etudiant/depot_memoire.php
 * Responsabilité : affichage uniquement.
 * Toutes les variables sont injectées par MemoireController.php
 * Ne contient aucune logique métier ni accès à la base de données.
 */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dépôt de mémoire — GéMémoires</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/depot.css">
</head>
<body>

<!-- ══ NAVBAR ══════════════════════════════════════════════════════════════ -->
<nav class="navbar">
    <a class="navbar-brand" href="#">
        📚 GéMémoires
        <span class="brand-sub">UATM GASA FORMATION</span>
    </a>
    <div class="navbar-links">
        <span class="nav-user">👤 <?= htmlspecialchars($_SESSION['nom'] ?? 'Étudiant') ?></span>
        <a href="../../controllers/ConsultationController.php?action=liste">🔍 Consulter</a>
        <a href="../../views/auth/logout.php" class="btn-logout">Déconnexion</a>
    </div>
</nav>

<div class="container">

    <div class="page-header">
        <h2>📤 Dépôt de mémoire</h2>
        <p class="text-muted">Soumettez votre mémoire pour validation par un professeur.</p>
    </div>

    <!-- ── Alertes flash ──────────────────────────────────────────────── -->
    <?php if (!empty($succes)): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($succes) ?></div>
    <?php endif; ?>

    <?php if (!empty($erreurs)): ?>
        <div class="alert alert-error">
            <strong>⚠️ Veuillez corriger les erreurs suivantes :</strong>
            <ul>
                <?php foreach ($erreurs as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- ── Mémoire déjà soumis ────────────────────────────────────────── -->
    <?php if ($mon_memoire): ?>
        <div class="statut-card">
            <h3>📋 Votre mémoire soumis</h3>
            <table>
                <tr><th>Thème</th>
                    <td><?= htmlspecialchars($mon_memoire['theme']) ?></td></tr>
                <tr><th>Filière</th>
                    <td><?= htmlspecialchars($mon_memoire['filiere']) ?></td></tr>
                <tr><th>Année</th>
                    <td><?= htmlspecialchars($mon_memoire['annee_academique']) ?></td></tr>
                <tr><th>Date soumission</th>
                    <td><?= date('d/m/Y H:i', strtotime($mon_memoire['date_soumission'])) ?></td></tr>
                <tr><th>Statut</th>
                    <td>
                        <?php
                        $badges = [
                            'en_attente' => ['badge-orange', '⏳ En attente de validation'],
                            'valide'     => ['badge-green',  '✅ Validé'],
                            'rejete'     => ['badge-red',    '❌ Rejeté'],
                        ];
                        $badge = $badges[$mon_memoire['statut']] ?? ['badge-gray', $mon_memoire['statut']];
                        ?>
                        <span class="badge <?= $badge[0] ?>"><?= $badge[1] ?></span>
                    </td>
                </tr>
            </table>

            <?php if ($mon_memoire['statut'] === 'valide'): ?>
                <a href="../../uploads/<?= htmlspecialchars($mon_memoire['fichier_pdf']) ?>"
                   target="_blank" class="btn btn-primary mt-10">
                    📄 Voir le fichier PDF
                </a>
            <?php endif; ?>
        </div>

        <div class="alert alert-error">
            ⚠️ Vous avez déjà soumis un mémoire. Un seul dépôt est autorisé par étudiant.
        </div>

    <?php else: ?>

    <!-- ── Formulaire de dépôt ────────────────────────────────────────── -->
    <form action="../../controllers/MemoireController.php"
          method="POST"
          enctype="multipart/form-data"
          onsubmit="return validerDepot()"
          class="form-depot">

        <h3>📝 Informations du mémoire</h3>

        <div class="form-row">
            <div class="form-group">
                <label for="theme">Thème du mémoire <span class="required">*</span></label>
                <input type="text" id="theme" name="theme"
                       placeholder="Ex : Développement d'une application de gestion..."
                       required maxlength="255">
            </div>
        </div>

        <div class="form-row two-cols">
            <div class="form-group">
                <label for="auteur">Auteur (Nom & Prénoms) <span class="required">*</span></label>
                <input type="text" id="auteur" name="auteur"
                       value="<?= htmlspecialchars(($_SESSION['nom'] ?? '') . ' ' . ($_SESSION['prenom'] ?? '')) ?>"
                       placeholder="DUPONT Jean" required maxlength="150">
            </div>
            <div class="form-group">
                <label for="filiere">Filière <span class="required">*</span></label>
                <select id="filiere" name="filiere" required>
                    <option value="">-- Choisir --</option>
                    <option value="SIL">SIL — Systèmes Informatiques et Logiciels</option>
                    <option value="GE">GE — Génie Électrique</option>
                    <option value="GC">GC — Génie Civil</option>
                    <option value="GI">GI — Génie Industriel</option>
                    <option value="RIT">RIT — Réseaux et Infrastructures</option>
                    <option value="Autre">Autre</option>
                </select>
            </div>
        </div>

        <div class="form-row two-cols">
            <div class="form-group">
                <label for="promotion">Promotion</label>
                <input type="text" id="promotion" name="promotion"
                       placeholder="Ex : Promotion 2024" maxlength="100">
            </div>
            <div class="form-group">
                <label for="annee_academique">Année académique <span class="required">*</span></label>
                <input type="text" id="annee_academique" name="annee_academique"
                       placeholder="2024-2025" pattern="\d{4}-\d{4}"
                       title="Format : AAAA-AAAA" required maxlength="9">
            </div>
        </div>

        <div class="form-group">
            <label for="resume">Résumé / Abstract</label>
            <textarea id="resume" name="resume" rows="5"
                      placeholder="Résumé de votre mémoire (500 mots max)..."
                      maxlength="2000"></textarea>
            <small class="hint" id="compteur_resume">0 / 2000 caractères</small>
        </div>

        <div class="form-group">
            <label for="fichier_pdf">Fichier PDF du mémoire <span class="required">*</span></label>
            <div class="upload-zone" id="upload_zone">
                <span class="upload-icon">📁</span>
                <p>Glissez-déposez votre PDF ici, ou <strong>cliquez pour parcourir</strong></p>
                <p class="hint">Format : PDF uniquement — Taille max : 20 Mo</p>
                <input type="file" id="fichier_pdf" name="fichier_pdf" accept=".pdf" required>
            </div>
            <div id="info_fichier" class="info-fichier" style="display:none;"></div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary btn-lg">
                📤 Soumettre le mémoire
            </button>
            <button type="reset" class="btn btn-secondary">
                🔄 Réinitialiser
            </button>
        </div>

    </form>
    <?php endif; ?>

</div>

<footer class="footer">
    <p>GéMémoires — UATM GASA FORMATION &copy; <?= date('Y') ?></p>
</footer>

<script src="../../assets/js/depot.js"></script>
</body>
</html>
