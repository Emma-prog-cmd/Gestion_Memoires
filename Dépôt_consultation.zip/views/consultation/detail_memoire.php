<?php
/**
 * VUE — views/consultation/detail_memoire.php
 * Responsabilité : affichage uniquement.
 * Variables injectées par ConsultationController.php :
 *   $memoire_detail, $commentaires, $a_like, $id_memoire
 */

$erreur = $_SESSION['erreur'] ?? '';
$succes = $_SESSION['succes'] ?? '';
unset($_SESSION['erreur'], $_SESSION['succes']);

$id_utilisateur = (int)$_SESSION['id_utilisateur'];
$id_memoire     = (int)$memoire_detail['id_memoire'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($memoire_detail['theme']) ?> — GéMémoires</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/consultation.css">
</head>
<body>

<nav class="navbar">
    <a class="navbar-brand" href="#">
        📚 GéMémoires
        <span class="brand-sub">UATM GASA FORMATION</span>
    </a>
    <div class="navbar-links">
        <a href="../../controllers/ConsultationController.php?action=liste">← Retour à la liste</a>
        <span class="nav-user">👤 <?= htmlspecialchars($_SESSION['nom'] ?? '') ?></span>
        <a href="../../views/auth/logout.php" class="btn-logout">Déconnexion</a>
    </div>
</nav>

<div class="container">

    <?php if ($erreur): ?>
        <div class="alert alert-error">⚠️ <?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>
    <?php if ($succes): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($succes) ?></div>
    <?php endif; ?>

    <div class="detail-layout">

        <!-- ── Colonne principale ──────────────────────────────────────── -->
        <div class="detail-main">

            <div class="detail-card">
                <div class="detail-top">
                    <span class="badge badge-blue"><?= htmlspecialchars($memoire_detail['filiere']) ?></span>
                    <span class="badge badge-green"><?= htmlspecialchars($memoire_detail['annee_academique']) ?></span>
                    <?php if (!empty($memoire_detail['promotion'])): ?>
                        <span class="badge badge-gray"><?= htmlspecialchars($memoire_detail['promotion']) ?></span>
                    <?php endif; ?>
                </div>

                <h1 class="detail-titre"><?= htmlspecialchars($memoire_detail['theme']) ?></h1>

                <p class="detail-auteur">
                    ✍️ <strong><?= htmlspecialchars($memoire_detail['auteur']) ?></strong>
                    &nbsp;·&nbsp;
                    📅 Soumis le <?= date('d/m/Y', strtotime($memoire_detail['date_soumission'])) ?>
                </p>

                <?php if (!empty($memoire_detail['resume'])): ?>
                    <div class="detail-resume">
                        <h3>📄 Résumé</h3>
                        <p><?= nl2br(htmlspecialchars($memoire_detail['resume'])) ?></p>
                    </div>
                <?php endif; ?>

                <div class="detail-actions">
                    <a href="../../uploads/<?= htmlspecialchars($memoire_detail['fichier_pdf']) ?>"
                       target="_blank" class="btn btn-primary btn-lg">
                        📥 Télécharger / Lire le PDF
                    </a>

                    <!-- Bouton Like — géré par le module Commentaire (collègue) -->
                    <button id="btn-like"
                            class="btn btn-like <?= $a_like ? 'liked' : '' ?>"
                            data-id="<?= $id_memoire ?>"
                            data-liked="<?= $a_like ? '1' : '0' ?>">
                        <?= $a_like ? '❤️' : '🤍' ?>
                        <span id="nb-likes"><?= (int)$memoire_detail['nb_likes'] ?></span>
                        Like<?= (int)$memoire_detail['nb_likes'] > 1 ? 's' : '' ?>
                    </button>
                </div>
            </div>

            <!-- ── Section Commentaires (module collègue) ─────────────── -->
            <div class="section-commentaires" id="commentaires">
                <h2>💬 Commentaires
                    <span class="badge badge-blue"><?= count($commentaires) ?></span>
                </h2>

                <!-- Formulaire d'ajout (module Commentaire) -->
                <form action="../../controllers/CommentaireController.php"
                      method="POST" class="form-commentaire">
                    <input type="hidden" name="action"     value="ajouter_commentaire">
                    <input type="hidden" name="id_memoire" value="<?= $id_memoire ?>">
                    <div class="form-group">
                        <label for="contenu">Votre commentaire</label>
                        <textarea id="contenu" name="contenu" rows="3"
                                  placeholder="Partagez votre avis..."
                                  maxlength="1000" required></textarea>
                        <small class="hint" id="compteur_cmt">0 / 1000 caractères</small>
                    </div>
                    <button type="submit" class="btn btn-primary">💬 Publier</button>
                </form>

                <!-- Liste des commentaires -->
                <div class="liste-commentaires">
                    <?php if (empty($commentaires)): ?>
                        <div class="empty-cmt">
                            <p>Aucun commentaire pour l'instant. Soyez le premier !</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($commentaires as $cmt): ?>
                            <div class="commentaire-item">
                                <div class="cmt-avatar">
                                    <?= strtoupper(mb_substr($cmt['nom'], 0, 1)) ?>
                                </div>
                                <div class="cmt-body">
                                    <div class="cmt-meta">
                                        <strong><?= htmlspecialchars($cmt['nom'] . ' ' . $cmt['prenom']) ?></strong>
                                        <span class="badge badge-gray cmt-role">
                                            <?= htmlspecialchars(str_replace('_', ' ', $cmt['role'])) ?>
                                        </span>
                                        <span class="cmt-date">
                                            <?= date('d/m/Y à H:i', strtotime($cmt['date_commentaire'])) ?>
                                        </span>
                                    </div>
                                    <p class="cmt-contenu">
                                        <?= nl2br(htmlspecialchars($cmt['contenu'])) ?>
                                    </p>
                                    <?php if ((int)$cmt['id_utilisateur'] === $id_utilisateur): ?>
                                        <form action="../../controllers/CommentaireController.php"
                                              method="POST" class="form-suppr-cmt"
                                              onsubmit="return confirm('Supprimer ce commentaire ?')">
                                            <input type="hidden" name="action" value="supprimer_commentaire">
                                            <input type="hidden" name="id_commentaire" value="<?= $cmt['id_commentaire'] ?>">
                                            <input type="hidden" name="id_memoire" value="<?= $id_memoire ?>">
                                            <button type="submit" class="btn-suppr-cmt">🗑 Supprimer</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div><!-- /detail-main -->

        <!-- ── Sidebar ────────────────────────────────────────────────── -->
        <aside class="detail-sidebar">
            <div class="sidebar-card">
                <h4>📊 Statistiques</h4>
                <div class="stat-item">
                    <span class="stat-icon">❤️</span>
                    <div>
                        <div class="stat-val"><?= (int)$memoire_detail['nb_likes'] ?></div>
                        <div class="stat-lbl">Likes</div>
                    </div>
                </div>
                <div class="stat-item">
                    <span class="stat-icon">💬</span>
                    <div>
                        <div class="stat-val"><?= (int)$memoire_detail['nb_commentaires'] ?></div>
                        <div class="stat-lbl">Commentaires</div>
                    </div>
                </div>
            </div>

            <div class="sidebar-card">
                <h4>ℹ️ Informations</h4>
                <ul class="info-list">
                    <li><strong>Filière :</strong> <?= htmlspecialchars($memoire_detail['filiere']) ?></li>
                    <li><strong>Année :</strong> <?= htmlspecialchars($memoire_detail['annee_academique']) ?></li>
                    <?php if (!empty($memoire_detail['promotion'])): ?>
                        <li><strong>Promotion :</strong> <?= htmlspecialchars($memoire_detail['promotion']) ?></li>
                    <?php endif; ?>
                    <li><strong>Statut :</strong> <span class="badge badge-green">✅ Validé</span></li>
                </ul>
            </div>

            <a href="../../controllers/ConsultationController.php?action=liste"
               class="btn btn-secondary btn-full mt-10">
                ← Retour à la liste
            </a>
        </aside>

    </div>
</div>

<footer class="footer">
    <p>GéMémoires — UATM GASA FORMATION &copy; <?= date('Y') ?></p>
</footer>

<script src="../../assets/js/consultation.js"></script>
<script>const BASE_URL = '../../';</script>
<script src="../../assets/js/like.js"></script>
</body>
</html>
