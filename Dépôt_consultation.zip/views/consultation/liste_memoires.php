<?php
/**
 * VUE — views/consultation/liste_memoires.php
 * Responsabilité : affichage uniquement.
 * Variables injectées par ConsultationController.php :
 *   $memoires, $total, $nb_pages, $page, $filieres, $annees,
 *   $mot_cle, $filiere, $annee
 */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mémoires — GéMémoires</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/consultation.css">
</head>
<body>

<nav class="navbar">
    <a class="navbar-brand" href="#">
        📚 GéMémoires
        <span class="brand-sub">UATM GASA FORMATION</span>
    </a>
    <div class="navbar-links">
        <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'etudiant_diplome'): ?>
            <a href="../../controllers/MemoireController.php">📤 Déposer</a>
        <?php endif; ?>
        <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'professeur'): ?>
            <a href="../../views/professeur/validation_memoire.php">✅ Validation</a>
        <?php endif; ?>
        <span class="nav-user">👤 <?= htmlspecialchars($_SESSION['nom'] ?? '') ?></span>
        <a href="../../views/auth/logout.php" class="btn-logout">Déconnexion</a>
    </div>
</nav>

<div class="container">

    <div class="page-header">
        <h2>📚 Mémoires disponibles</h2>
        <p class="text-muted">
            <?= (int)$total ?> mémoire<?= $total > 1 ? 's' : '' ?> trouvé<?= $total > 1 ? 's' : '' ?>
        </p>
    </div>

    <!-- ── Formulaire de recherche ───────────────────────────────────── -->
    <form method="GET" action="../../controllers/ConsultationController.php" class="form-recherche">
        <input type="hidden" name="action" value="recherche">
        <div class="recherche-principale">
            <input type="text" id="mot_cle" name="mot_cle"
                   value="<?= htmlspecialchars($mot_cle) ?>"
                   placeholder="🔍 Rechercher par thème, auteur..."
                   class="input-recherche" autocomplete="off">
            <button type="submit" class="btn btn-primary">Rechercher</button>
            <a href="../../controllers/ConsultationController.php?action=liste"
               class="btn btn-secondary">Réinitialiser</a>
        </div>
        <div class="filtres">
            <select name="filiere">
                <option value="">Toutes les filières</option>
                <?php foreach ($filieres as $f): ?>
                    <option value="<?= htmlspecialchars($f) ?>"
                        <?= $filiere === $f ? 'selected' : '' ?>>
                        <?= htmlspecialchars($f) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="annee">
                <option value="">Toutes les années</option>
                <?php foreach ($annees as $a): ?>
                    <option value="<?= htmlspecialchars($a) ?>"
                        <?= $annee === $a ? 'selected' : '' ?>>
                        <?= htmlspecialchars($a) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <!-- ── Grille des mémoires ───────────────────────────────────────── -->
    <?php if (empty($memoires)): ?>
        <div class="empty-state">
            <span class="empty-icon">📭</span>
            <h3>Aucun mémoire trouvé</h3>
            <p>Essayez d'autres termes de recherche.</p>
            <a href="../../controllers/ConsultationController.php?action=liste"
               class="btn btn-primary">Voir tous les mémoires</a>
        </div>
    <?php else: ?>
        <div class="memoires-grid">
            <?php foreach ($memoires as $m): ?>
                <div class="memoire-card">
                    <div class="card-header">
                        <span class="badge badge-blue"><?= htmlspecialchars($m['filiere']) ?></span>
                        <span class="card-annee"><?= htmlspecialchars($m['annee_academique']) ?></span>
                    </div>
                    <div class="card-body">
                        <h3 class="card-titre">
                            <?= htmlspecialchars(mb_strimwidth($m['theme'], 0, 90, '…')) ?>
                        </h3>
                        <p class="card-auteur">✍️ <?= htmlspecialchars($m['auteur']) ?></p>
                        <?php if (!empty($m['resume'])): ?>
                            <p class="card-resume">
                                <?= htmlspecialchars(mb_strimwidth($m['resume'], 0, 120, '…')) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <div class="card-stats">
                            <span>❤️ <?= (int)$m['nb_likes'] ?></span>
                            <span>💬 <?= (int)$m['nb_commentaires'] ?></span>
                        </div>
                        <a href="../../controllers/ConsultationController.php?action=detail&id=<?= $m['id_memoire'] ?>"
                           class="btn btn-primary btn-sm">
                            👁 Voir
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- ── Pagination ────────────────────────────────────────────── -->
        <?php if ($nb_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="../../controllers/ConsultationController.php?action=liste&page=<?= $page - 1 ?>"
                       class="btn btn-secondary">← Précédent</a>
                <?php endif; ?>

                <span class="page-info">Page <?= $page ?> / <?= $nb_pages ?></span>

                <?php if ($page < $nb_pages): ?>
                    <a href="../../controllers/ConsultationController.php?action=liste&page=<?= $page + 1 ?>"
                       class="btn btn-secondary">Suivant →</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<footer class="footer">
    <p>GéMémoires — UATM GASA FORMATION &copy; <?= date('Y') ?></p>
</footer>

<script src="../../assets/js/consultation.js"></script>
</body>
</html>
