/**
 * like.js — Gestion du bouton Like en AJAX
 */

document.addEventListener('DOMContentLoaded', function () {

    const btnLike = document.getElementById('btn-like');
    if (!btnLike) return;

    // BASE_URL est défini dans detail_memoire.php avant l'inclusion de ce script
    const baseUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL : '../../';

    btnLike.addEventListener('click', function () {

        const idMemoire = this.dataset.id;
        btnLike.disabled = true;

        const formData = new FormData();
        formData.append('action',     'toggle_like');
        formData.append('id_memoire', idMemoire);

        fetch(baseUrl + 'controllers/CommentaireController.php', {
            method:  'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body:    formData
        })
        .then(function (response) {
            if (!response.ok) throw new Error('Erreur réseau ' + response.status);
            return response.json();
        })
        .then(function (data) {
            if (data.succes) {
                const nbLikes = data.nb_likes;
                const liked   = data.liked;

                btnLike.classList.toggle('liked', liked);
                btnLike.dataset.liked = liked ? '1' : '0';

                btnLike.innerHTML =
                    (liked ? '❤️' : '🤍') +
                    ' <span id="nb-likes">' + nbLikes + '</span>' +
                    ' Like' + (nbLikes > 1 ? 's' : '');

            } else if (data.erreur) {
                alert(data.erreur);
            }
        })
        .catch(function (err) {
            console.error('Erreur like :', err);
            alert('Une erreur est survenue. Veuillez réessayer.');
        })
        .finally(function () {
            btnLike.disabled = false;
        });
    });
});
