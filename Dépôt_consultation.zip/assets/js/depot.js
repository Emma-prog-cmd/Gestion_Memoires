/**
 * depot.js — Validation côté client + drag & drop PDF
 */

document.addEventListener('DOMContentLoaded', function () {

    // ── Compteur de caractères (résumé) ──────────────────────────
    const resume   = document.getElementById('resume');
    const compteur = document.getElementById('compteur_resume');

    if (resume && compteur) {
        resume.addEventListener('input', function () {
            const len = this.value.length;
            compteur.textContent = len + ' / 2000 caractères';
            compteur.style.color = len > 1900 ? '#dc2626' : '#9ca3af';
        });
    }

    // ── Drag & Drop zone upload ───────────────────────────────────
    const zone      = document.getElementById('upload_zone');
    const input     = document.getElementById('fichier_pdf');
    const infoFich  = document.getElementById('info_fichier');

    if (zone && input) {
        // Afficher infos quand fichier sélectionné
        input.addEventListener('change', function () {
            afficherInfoFichier(this.files[0]);
        });

        zone.addEventListener('dragover', function (e) {
            e.preventDefault();
            zone.classList.add('drag-over');
        });

        zone.addEventListener('dragleave', function () {
            zone.classList.remove('drag-over');
        });

        zone.addEventListener('drop', function (e) {
            e.preventDefault();
            zone.classList.remove('drag-over');
            const fichier = e.dataTransfer.files[0];
            if (fichier) {
                // Transférer le fichier dans l'input
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(fichier);
                input.files = dataTransfer.files;
                afficherInfoFichier(fichier);
            }
        });
    }

    function afficherInfoFichier(fichier) {
        if (!fichier || !infoFich) return;
        const tailleKo = (fichier.size / 1024).toFixed(1);
        const tailleMo = (fichier.size / (1024 * 1024)).toFixed(2);
        const ext      = fichier.name.split('.').pop().toLowerCase();

        if (ext !== 'pdf') {
            infoFich.style.display    = 'block';
            infoFich.style.background = '#fee2e2';
            infoFich.style.color      = '#991b1b';
            infoFich.style.borderLeft = '3px solid #ef4444';
            infoFich.textContent      = '❌ Seuls les fichiers PDF sont acceptés.';
            return;
        }

        infoFich.style.display    = 'block';
        infoFich.style.background = '#dcfce7';
        infoFich.style.color      = '#166534';
        infoFich.style.borderLeft = '3px solid #22c55e';
        infoFich.innerHTML =
            '✅ <strong>' + fichier.name + '</strong> — ' +
            (fichier.size > 1024 * 1024 ? tailleMo + ' Mo' : tailleKo + ' Ko');
    }
});

// ── Validation globale avant soumission ──────────────────────────
function validerDepot() {
    const theme     = document.getElementById('theme');
    const auteur    = document.getElementById('auteur');
    const filiere   = document.getElementById('filiere');
    const annee     = document.getElementById('annee_academique');
    const fichier   = document.getElementById('fichier_pdf');

    // Champs obligatoires
    const champs = [
        { el: theme,   nom: 'le thème' },
        { el: auteur,  nom: "l'auteur" },
        { el: filiere, nom: 'la filière' },
        { el: annee,   nom: "l'année académique" },
    ];

    for (const c of champs) {
        if (!c.el || c.el.value.trim() === '') {
            alert('Veuillez renseigner ' + c.nom + '.');
            c.el && c.el.focus();
            return false;
        }
    }

    // Fichier obligatoire
    if (!fichier || fichier.files.length === 0) {
        alert('Veuillez sélectionner un fichier PDF.');
        return false;
    }

    // Extension PDF
    const ext = fichier.files[0].name.split('.').pop().toLowerCase();
    if (ext !== 'pdf') {
        alert('Seuls les fichiers PDF sont acceptés.');
        return false;
    }

    // Taille max 20 Mo
    if (fichier.files[0].size > 20 * 1024 * 1024) {
        alert('Le fichier dépasse 20 Mo. Veuillez en choisir un plus léger.');
        return false;
    }

    // Format année académique
    const regexAnnee = /^\d{4}-\d{4}$/;
    if (!regexAnnee.test(annee.value.trim())) {
        alert("Le format de l'année académique doit être : AAAA-AAAA (ex: 2024-2025).");
        annee.focus();
        return false;
    }

    return true; // tout est OK → envoi du formulaire
}
