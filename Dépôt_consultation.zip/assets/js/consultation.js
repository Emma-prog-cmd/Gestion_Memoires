/**
 * consultation.js — Interactions sur les pages liste et détail
 */

document.addEventListener('DOMContentLoaded', function () {

    // ── Compteur de caractères (commentaire) ─────────────────────
    const textarea  = document.getElementById('contenu');
    const compteur  = document.getElementById('compteur_cmt');

    if (textarea && compteur) {
        textarea.addEventListener('input', function () {
            const len = this.value.length;
            compteur.textContent = len + ' / 1000 caractères';
            compteur.style.color = len > 900 ? '#dc2626' : '#9ca3af';
        });
    }

    // ── Auto-scroll vers les commentaires si #commentaires dans l'URL ──
    if (window.location.hash === '#commentaires') {
        const section = document.getElementById('commentaires');
        if (section) {
            setTimeout(function () {
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 200);
        }
    }

    // ── Confirmation suppression commentaire ─────────────────────
    document.querySelectorAll('.form-suppr-cmt').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            if (!confirm('Voulez-vous vraiment supprimer ce commentaire ?')) {
                e.preventDefault();
            }
        });
    });

    // ── Recherche en temps réel côté client ──────────────────────
    // Sélecteur corrigé : .memoire-card (et non .carte-memoire)
    const inputRecherche = document.getElementById('mot_cle');
    const cartes         = document.querySelectorAll('.memoire-card');

    if (inputRecherche && cartes.length > 0) {
        inputRecherche.addEventListener('input', function () {
            const val = this.value.toLowerCase().trim();

            if (val === '') {
                cartes.forEach(c => c.style.display = '');
                return;
            }

            cartes.forEach(function (carte) {
                const titre  = carte.querySelector('.card-titre')?.textContent.toLowerCase()  || '';
                const auteur = carte.querySelector('.card-auteur')?.textContent.toLowerCase() || '';
                const resume = carte.querySelector('.card-resume')?.textContent.toLowerCase() || '';

                carte.style.display = (titre.includes(val) || auteur.includes(val) || resume.includes(val))
                    ? '' : 'none';
            });
        });
    }

    // ── Highlight des mots recherchés dans les cartes ────────────
    const urlParams = new URLSearchParams(window.location.search);
    const motCle    = urlParams.get('mot_cle');

    if (motCle && motCle.trim() !== '') {
        highlightTexte(motCle.trim());
    }

    function highlightTexte(mot) {
        const cibles = document.querySelectorAll('.card-titre, .card-auteur, .card-resume');
        const regex  = new RegExp('(' + escapeRegex(mot) + ')', 'gi');

        cibles.forEach(function (el) {
            el.innerHTML = el.innerHTML.replace(regex,
                '<mark style="background:#fef08a;border-radius:2px;padding:0 2px;">$1</mark>'
            );
        });
    }

    function escapeRegex(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
});
