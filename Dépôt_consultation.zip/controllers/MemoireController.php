<?php
/**
 * CONTRÔLEUR — MemoireController.php
 * Responsabilité : traiter la requête HTTP du dépôt de mémoire.
 * Appelle le Modèle, puis redirige ou charge la Vue.
 * Aucun HTML ici.
 */

session_start();
require_once(__DIR__ . '/../models/Memoire.php');

// ── 1. Vérification session ───────────────────────────────────────────────────
if (!isset($_SESSION['id_utilisateur'])) {
    header('Location: ../views/auth/login.php');
    exit();
}

if ($_SESSION['role'] !== 'etudiant_diplome') {
    $_SESSION['erreur'] = "Accès réservé aux étudiants diplômés.";
    header('Location: ../views/etudiant/depot_memoire.php');
    exit();
}

// ── 2. Affichage du formulaire (GET) ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id_etudiant  = (int)$_SESSION['id_utilisateur'];
    $memoireModel = new Memoire();
    $mon_memoire  = $memoireModel->getMemoireEtudiant($id_etudiant);

    // Messages flash
    $erreurs = $_SESSION['erreurs_depot'] ?? [];
    $succes  = $_SESSION['succes']        ?? '';
    unset($_SESSION['erreurs_depot'], $_SESSION['succes']);

    require_once(__DIR__ . '/../views/etudiant/depot_memoire.php');
    exit();
}

// ── 3. Traitement du formulaire (POST) ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_etudiant  = (int)$_SESSION['id_utilisateur'];
    $memoireModel = new Memoire();

    // --- Récupération des champs ---
    $theme            = trim($_POST['theme']            ?? '');
    $filiere          = trim($_POST['filiere']          ?? '');
    $auteur           = trim($_POST['auteur']           ?? '');
    $promotion        = trim($_POST['promotion']        ?? '');
    $annee_academique = trim($_POST['annee_academique'] ?? '');
    $resume           = trim($_POST['resume']           ?? '');

    // --- Validation ---
    $erreurs = [];
    if (empty($theme))            $erreurs[] = "Le thème est obligatoire.";
    if (empty($filiere))          $erreurs[] = "La filière est obligatoire.";
    if (empty($auteur))           $erreurs[] = "Le nom de l'auteur est obligatoire.";
    if (empty($annee_academique)) $erreurs[] = "L'année académique est obligatoire.";

    if (!preg_match('/^\d{4}-\d{4}$/', $annee_academique)) {
        $erreurs[] = "L'année académique doit être au format AAAA-AAAA.";
    }

    // --- Vérification unicité dépôt ---
    if ($memoireModel->aDejaDepose($id_etudiant)) {
        $erreurs[] = "Vous avez déjà soumis un mémoire. Un seul dépôt est autorisé.";
    }

    // --- Traitement du fichier PDF ---
    $fichier_pdf = '';
    if (empty($_FILES['fichier_pdf']['name'])) {
        $erreurs[] = "Le fichier PDF est obligatoire.";
    } else {
        $fichier   = $_FILES['fichier_pdf'];
        $extension = strtolower(pathinfo($fichier['name'], PATHINFO_EXTENSION));

        if ($extension !== 'pdf') {
            $erreurs[] = "Seuls les fichiers PDF sont acceptés.";
        } elseif ($fichier['size'] > 20 * 1024 * 1024) {
            $erreurs[] = "Le fichier ne doit pas dépasser 20 Mo.";
        } else {
            $nom_fichier = time() . '_' . preg_replace('/\s+/', '_', $fichier['name']);
            $chemin_dest = __DIR__ . '/../uploads/' . $nom_fichier;

            if (!move_uploaded_file($fichier['tmp_name'], $chemin_dest)) {
                $erreurs[] = "Erreur lors de l'envoi du fichier. Réessayez.";
            } else {
                $fichier_pdf = $nom_fichier;
            }
        }
    }

    // --- Erreurs → retour au formulaire ---
    if (!empty($erreurs)) {
        $_SESSION['erreurs_depot'] = $erreurs;
        header('Location: ../controllers/MemoireController.php');
        exit();
    }

    // --- Enregistrement en base (Modèle) ---
    $memoireModel->deposer(
        $theme, $filiere, $auteur, $promotion,
        $annee_academique, $resume, $fichier_pdf, $id_etudiant
    );

    $_SESSION['succes'] = "Votre mémoire a été soumis avec succès ! Il est en attente de validation.";
    header('Location: ../controllers/MemoireController.php');
    exit();
}

// Accès direct sans GET ni POST → redirection
header('Location: ../controllers/MemoireController.php');
exit();
?>
