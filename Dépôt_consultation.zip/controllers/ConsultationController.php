<?php
/**
 * CONTRÔLEUR — ConsultationController.php
 * Responsabilité : traiter les requêtes HTTP de consultation.
 * Appelle le Modèle, prépare les données, charge la Vue.
 * Aucun HTML ici.
 */

session_start();
require_once(__DIR__ . '/../models/Memoire.php');

// ── 1. Vérification session ───────────────────────────────────────────────────
if (!isset($_SESSION['id_utilisateur'])) {
    header('Location: ../views/auth/login.php');
    exit();
}

$memoireModel = new Memoire();
$action       = $_GET['action'] ?? 'liste';

switch ($action) {

    // ─── LISTE ────────────────────────────────────────────────────────────
    case 'liste':
        $par_page = 9;
        $page     = max(1, (int)($_GET['page'] ?? 1));
        $offset   = ($page - 1) * $par_page;

        $memoires = $memoireModel->getMemoiresValides($par_page, $offset);
        $total    = $memoireModel->countValides();
        $nb_pages = (int)ceil($total / $par_page);
        $filieres = $memoireModel->getFilieres();
        $annees   = $memoireModel->getAnnees();

        // Pas de filtre actif
        $mot_cle = '';
        $filiere = '';
        $annee   = '';

        require_once(__DIR__ . '/../views/consultation/liste_memoires.php');
        break;

    // ─── RECHERCHE ────────────────────────────────────────────────────────
    case 'recherche':
        $mot_cle = trim($_GET['mot_cle'] ?? '');
        $filiere = trim($_GET['filiere']  ?? '');
        $annee   = trim($_GET['annee']    ?? '');

        $memoires = $memoireModel->rechercher($mot_cle, $filiere, $annee);
        $total    = count($memoires);
        $nb_pages = 1;
        $page     = 1;
        $filieres = $memoireModel->getFilieres();
        $annees   = $memoireModel->getAnnees();

        require_once(__DIR__ . '/../views/consultation/liste_memoires.php');
        break;

    // ─── DÉTAIL ───────────────────────────────────────────────────────────
    case 'detail':
        $id_memoire = (int)($_GET['id'] ?? 0);

        if ($id_memoire <= 0) {
            $_SESSION['erreur'] = "Identifiant de mémoire invalide.";
            header('Location: ../controllers/ConsultationController.php?action=liste');
            exit();
        }

        $memoire_detail = $memoireModel->getById($id_memoire);

        if (!$memoire_detail) {
            $_SESSION['erreur'] = "Ce mémoire n'existe pas ou n'est pas encore validé.";
            header('Location: ../controllers/ConsultationController.php?action=liste');
            exit();
        }

        // Les commentaires et likes sont gérés par les collègues
        // On récupère via leurs modèles s'ils sont disponibles
        $commentaires = [];
        $a_like       = false;
        if (file_exists(__DIR__ . '/../models/Commentaire.php')) {
            require_once(__DIR__ . '/../models/Commentaire.php');
            $commentaireModel = new Commentaire();
            $commentaires     = $commentaireModel->getCommentairesMemoire($id_memoire);
            $a_like           = $commentaireModel->aLike(
                (int)$_SESSION['id_utilisateur'], $id_memoire
            );
        }

        require_once(__DIR__ . '/../views/consultation/detail_memoire.php');
        break;

    // ─── DEFAULT ──────────────────────────────────────────────────────────
    default:
        header('Location: ../controllers/ConsultationController.php?action=liste');
        exit();
}
?>
