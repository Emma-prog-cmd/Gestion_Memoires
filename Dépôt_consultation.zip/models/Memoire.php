<?php
/**
 * MODÈLE — Memoire.php
 * Responsabilité : accès aux données de la table `memoire` uniquement.
 * Aucune logique HTTP, aucune session, aucun affichage ici.
 */

require_once(__DIR__ . '/../config/connexion.php');

class Memoire {

    // =========================================================
    //  DÉPÔT
    // =========================================================

    /**
     * Insère un nouveau mémoire en base (statut = en_attente).
     * Retourne l'id inséré.
     */
    public function deposer(
        string $theme,
        string $filiere,
        string $auteur,
        string $promotion,
        string $annee_academique,
        string $resume,
        string $fichier_pdf,
        int    $id_etudiant
    ): int {
        global $connexion;

        $sql = "INSERT INTO memoire
                    (theme, filiere, auteur, promotion,
                     annee_academique, resume, fichier_pdf,
                     statut, id_etudiant)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'en_attente', ?)";

        $stmt = $connexion->prepare($sql);
        $stmt->execute([
            $theme, $filiere, $auteur, $promotion,
            $annee_academique, $resume, $fichier_pdf, $id_etudiant
        ]);

        return (int)$connexion->lastInsertId();
    }

    /**
     * Vérifie si l'étudiant a déjà déposé un mémoire.
     */
    public function aDejaDepose(int $id_etudiant): bool {
        global $connexion;

        $stmt = $connexion->prepare(
            "SELECT COUNT(*) FROM memoire WHERE id_etudiant = ?"
        );
        $stmt->execute([$id_etudiant]);
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Récupère le mémoire soumis par un étudiant (le plus récent).
     */
    public function getMemoireEtudiant(int $id_etudiant): ?array {
        global $connexion;

        $stmt = $connexion->prepare(
            "SELECT m.*, u.nom, u.prenom
             FROM memoire m
             JOIN utilisateur u ON m.id_etudiant = u.id_utilisateur
             WHERE m.id_etudiant = ?
             ORDER BY m.date_soumission DESC
             LIMIT 1"
        );
        $stmt->execute([$id_etudiant]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    // =========================================================
    //  CONSULTATION / RECHERCHE
    // =========================================================

    /**
     * Retourne les mémoires validés, paginés.
     */
    public function getMemoiresValides(int $limite = 9, int $offset = 0): array {
        global $connexion;

        $sql = "SELECT m.*,
                       u.nom, u.prenom,
                       (SELECT COUNT(*) FROM likes
                        WHERE id_memoire = m.id_memoire) AS nb_likes,
                       (SELECT COUNT(*) FROM commentaire
                        WHERE id_memoire = m.id_memoire) AS nb_commentaires
                FROM memoire m
                JOIN utilisateur u ON m.id_etudiant = u.id_utilisateur
                WHERE m.statut = 'valide'
                ORDER BY m.date_soumission DESC
                LIMIT $limite OFFSET $offset";

        $stmt = $connexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Recherche par mot-clé, filière et/ou année.
     */
    public function rechercher(
        string $mot_cle = '',
        string $filiere  = '',
        string $annee    = ''
    ): array {
        global $connexion;

        $params     = [];
        $conditions = ["m.statut = 'valide'"];

        if (!empty($mot_cle)) {
            $conditions[] = "(m.theme LIKE ? OR m.auteur LIKE ? OR m.resume LIKE ?)";
            $like = "%$mot_cle%";
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        if (!empty($filiere)) {
            $conditions[] = "m.filiere = ?";
            $params[] = $filiere;
        }
        if (!empty($annee)) {
            $conditions[] = "m.annee_academique = ?";
            $params[] = $annee;
        }

        $where = implode(' AND ', $conditions);
        $sql   = "SELECT m.*,
                         u.nom, u.prenom,
                         (SELECT COUNT(*) FROM likes
                          WHERE id_memoire = m.id_memoire) AS nb_likes,
                         (SELECT COUNT(*) FROM commentaire
                          WHERE id_memoire = m.id_memoire) AS nb_commentaires
                  FROM memoire m
                  JOIN utilisateur u ON m.id_etudiant = u.id_utilisateur
                  WHERE $where
                  ORDER BY m.date_soumission DESC";

        $stmt = $connexion->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Retourne le détail complet d'un mémoire validé.
     */
    public function getById(int $id_memoire): ?array {
        global $connexion;

        $stmt = $connexion->prepare(
            "SELECT m.*,
                    u.nom, u.prenom, u.email,
                    (SELECT COUNT(*) FROM likes
                     WHERE id_memoire = m.id_memoire) AS nb_likes,
                    (SELECT COUNT(*) FROM commentaire
                     WHERE id_memoire = m.id_memoire) AS nb_commentaires
             FROM memoire m
             JOIN utilisateur u ON m.id_etudiant = u.id_utilisateur
             WHERE m.id_memoire = ? AND m.statut = 'valide'"
        );
        $stmt->execute([$id_memoire]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    /**
     * Liste des filières disponibles (pour les filtres).
     */
    public function getFilieres(): array {
        global $connexion;

        $stmt = $connexion->query(
            "SELECT DISTINCT filiere FROM memoire
             WHERE statut = 'valide' ORDER BY filiere"
        );
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Liste des années académiques disponibles (pour les filtres).
     */
    public function getAnnees(): array {
        global $connexion;

        $stmt = $connexion->query(
            "SELECT DISTINCT annee_academique FROM memoire
             WHERE statut = 'valide' ORDER BY annee_academique DESC"
        );
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Nombre total de mémoires validés (pour la pagination).
     */
    public function countValides(): int {
        global $connexion;

        $stmt = $connexion->query(
            "SELECT COUNT(*) FROM memoire WHERE statut = 'valide'"
        );
        return (int)$stmt->fetchColumn();
    }
}
?>
